#
# TABLE STRUCTURE FOR: bqueue
#

DROP TABLE IF EXISTS bqueue;

CREATE TABLE `bqueue` (
  `idBqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idBqueue`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO bqueue (`idBqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (22, '5c8e5f2c3feaac797d4534758b6660d8', 86, 'd2fc91e2d4ce2d0609e3b578a406471c', 'inprogress', '2012-08-20 13:04:10');
INSERT INTO bqueue (`idBqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (23, '5c8e5f2c3feaac797d4534758b6660d8', 87, 'd2fc91e2d4ce2d0609e3b578a406471c', 'inprogress', '2012-08-20 13:04:10');


#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `idCategories` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  PRIMARY KEY (`idCategories`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='Main Courses, Appetizers etc';

INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (14, 'Category one', '', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (12, 'Category two', 'boo', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (15, 'Menu Prova Cat', '', 0, NULL);


#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS config;

CREATE TABLE `config` (
  `device` varchar(45) NOT NULL,
  `key` varchar(45) DEFAULT NULL,
  `value` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'mininterval', '60000');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxitems', '0');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxrounds', '0');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'servuilang', 'english');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'restmode', 'alacarte');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'displaymode', 'listview');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'currency', '€');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'price', '{\"adults\":\"11.27\",\"children\":\"6.49\"}');


#
# TABLE STRUCTURE FOR: images
#

DROP TABLE IF EXISTS images;

CREATE TABLE `images` (
  `idImages` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `fileName` varchar(100) NOT NULL,
  PRIMARY KEY (`idImages`),
  UNIQUE KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (42, 'Coke', 'coca.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (41, 'Pesce2', 'img.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (40, 'Pesce1', '54-2-zoom-2-il_ristorante_5.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (39, 'wine', 'wine2.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (51, 'food', 'food_(800x600).jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (52, 'logo', 'logo.png');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `idItems` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `description` mediumtext,
  `idImage` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `extras` mediumtext,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idItems`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT=' food and beverages items';

INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (1, 'Food number 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (2, 'Uno', 'Tre', 0, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (3, 'due onw', 'ono', 37, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (4, 'Food number 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (5, 'Food number 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (6, 'Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (7, 'Coca cola', 'Coca cola', 42, '1.00', NULL, 'n');


#
# TABLE STRUCTURE FOR: kqueue
#

DROP TABLE IF EXISTS kqueue;

CREATE TABLE `kqueue` (
  `idKqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idKqueue`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

INSERT INTO kqueue (`idKqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (44, '5c8e5f2c3feaac797d4534758b6660d8', 84, 'd2fc91e2d4ce2d0609e3b578a406471c', 'done', '2012-08-20 13:04:10');
INSERT INTO kqueue (`idKqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (45, '5c8e5f2c3feaac797d4534758b6660d8', 85, 'd2fc91e2d4ce2d0609e3b578a406471c', 'done', '2012-08-20 13:04:10');


#
# TABLE STRUCTURE FOR: menulists
#

DROP TABLE IF EXISTS menulists;

CREATE TABLE `menulists` (
  `idMenulists` int(11) NOT NULL AUTO_INCREMENT,
  `fk_idMenus` int(11) DEFAULT NULL,
  `fk_idCategories` int(11) DEFAULT NULL,
  `fk_idItems` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `categoryPosition` tinyint(4) DEFAULT '0',
  `itemPosition` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idMenulists`),
  KEY `fk_idMenus` (`fk_idMenus`),
  KEY `fk_idCategories` (`fk_idCategories`),
  KEY `fk_idItems` (`fk_idItems`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (24, 31, 14, 6, '2.99', 2, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (36, 31, 14, 1, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (26, 31, 12, 5, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (5, 31, 13, 4, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (6, 31, 13, 4, '2.99', 1, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (7, 31, 13, 3, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (9, 31, 0, 4, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (10, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (11, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (12, 31, 13, 3, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (23, 31, 12, 6, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (14, 31, 13, 3, '2.99', 1, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (35, 31, 12, 1, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (18, 30, 12, 6, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (28, 31, 14, 4, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (30, 31, 14, 4, '2.99', 2, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (33, 31, 14, 6, '2.99', 2, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (39, 30, 14, 7, '1.00', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (38, 30, 12, 4, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (37, 30, 14, 5, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (45, 35, 14, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (41, 32, 12, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (42, 32, 14, 7, '1.00', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (43, 31, 15, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (46, 35, 12, 4, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (47, 35, 15, 5, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (49, 35, 15, 6, '2.99', 0, 0);


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `idMenus` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  `price` tinytext,
  `visible` varchar(10) DEFAULT NULL,
  `menuType` enum('f','c') DEFAULT 'c',
  `foodbev` enum('f','b') DEFAULT 'f',
  `position` tinyint(4) DEFAULT NULL,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idMenus`),
  UNIQUE KEY `label_UNIQUE` (`label`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='A la carte, Vegetarian, early birds etc...';

INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (27, 'AhAH', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (26, 'testmenu', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (17, 'Food menu', 'Test Food menu', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (32, 'Menu of the day', '', 0, NULL, NULL, 'y', 'c', 'f', 2, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (31, 'Grill menu', '', 0, NULL, NULL, 'y', 'c', 'f', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (28, 'ahahah', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (29, 'Wine List', 'bla', 0, NULL, NULL, 'y', 'c', 'b', 2, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (30, 'Drinks', '', 0, NULL, NULL, 'y', 'c', 'b', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (33, 'test', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (34, 'Menu prova', '', 0, NULL, NULL, 'y', 'c', 'f', 3, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (35, 'Demo Menu', '', 0, NULL, NULL, 'y', 'c', 'f', 2, 'n');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `idModules` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  PRIMARY KEY (`idModules`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO modules (`idModules`, `label`) VALUES (0, 'admin');
INSERT INTO modules (`idModules`, `label`) VALUES (1, 'menuconf');
INSERT INTO modules (`idModules`, `label`) VALUES (2, 'orders');
INSERT INTO modules (`idModules`, `label`) VALUES (3, 'kitchen');
INSERT INTO modules (`idModules`, `label`) VALUES (4, 'bar');


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS orders;

CREATE TABLE `orders` (
  `idOrders` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(45) NOT NULL,
  `fk_idMenulists` int(11) DEFAULT NULL,
  `number` smallint(6) DEFAULT NULL,
  `note` mediumtext NOT NULL,
  `ksent` enum('y','n') NOT NULL DEFAULT 'n',
  `status` enum('received','inprogress','done') NOT NULL DEFAULT 'received',
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`idOrders`),
  KEY `fk_idMenulists` (`fk_idMenulists`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (33, '75d991cf066f547e95f07556d808f1c2', 39, 2, '', 'y', 'received', '2012-06-05 20:50:23');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (34, '75d991cf066f547e95f07556d808f1c2', 35, 2, '', 'y', 'received', '2012-06-05 20:51:30');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (35, '75d991cf066f547e95f07556d808f1c2', 26, 1, '', 'y', 'received', '2012-06-05 21:16:07');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (12, '27247c410786f8af754b4eb58787f75c', 35, 4, '', 'y', 'received', '2012-04-23 17:09:14');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (13, '27247c410786f8af754b4eb58787f75c', 36, 2, '', 'y', 'received', '2012-04-23 20:43:27');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (39, 'b6cd8129a47100d8ba88efaf6d3f5718', 35, 1, '', 'y', 'received', '2012-06-09 08:58:25');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (38, 'b6cd8129a47100d8ba88efaf6d3f5718', 39, 1, '', 'y', 'received', '2012-06-09 08:57:33');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (37, '75d991cf066f547e95f07556d808f1c2', 23, 2, '', 'y', 'received', '2012-06-06 23:04:20');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (36, 'c5d6d8aad6d3d828f3e87cf5f98de5a4', 23, 1, '', 'y', 'received', '2012-06-05 21:17:25');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (28, '52dd7d495a1bb29d921550867d57fb7c', 39, 2, '', 'y', 'received', '2012-05-17 07:01:01');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (29, '52dd7d495a1bb29d921550867d57fb7c', 35, 2, '', 'y', 'received', '2012-05-17 07:04:50');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (30, '52dd7d495a1bb29d921550867d57fb7c', 35, 3, '', 'y', 'received', '2012-06-05 21:19:35');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (40, 'b6cd8129a47100d8ba88efaf6d3f5718', 37, 2, '', 'y', 'received', '2012-07-27 16:42:56');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (41, 'b6cd8129a47100d8ba88efaf6d3f5718', 18, 2, '', 'y', 'received', '2012-07-31 17:06:53');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (42, '3a150d4f9839b51a0da4b18f9933e27a', 18, 2, '', 'y', 'received', '2012-08-11 16:08:02');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (43, '079ae02de0411a09d585a220772dc206', 26, 2, '', 'y', 'received', '2012-08-14 13:06:15');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (47, 'a4888526acc0a0ac778cfaa3c4109345', 26, 2, '', 'y', 'received', '2012-08-15 16:34:10');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (48, '4640b22e0612366d673c21f2ffc47711', 26, 2, '', 'y', 'received', '2012-08-15 16:43:49');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (49, 'e3007fc2f2b9b3fc942ff1e052b16bf8', 26, 2, '', 'y', 'received', '2012-08-15 16:48:29');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (50, 'adb9ae1f14ed8986ead92ce55207e589', 26, 1, '', 'y', 'received', '2012-08-15 16:58:20');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (51, '71067202fd433b6f7e33caa3ce0ae1b6', 26, 1, '', 'y', 'received', '2012-08-15 17:01:29');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (52, 'e38d72ea41a1cd46121a95997988eea3', 26, 1, '', 'y', 'received', '2012-08-15 17:12:33');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (53, '1e5bc7d375076268da746ab5fd0688e7', 26, 1, '', 'y', 'received', '2012-08-16 17:07:55');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (54, '1e5bc7d375076268da746ab5fd0688e7', 39, 1, '', 'y', 'received', '2012-08-16 17:35:20');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (55, '1e5bc7d375076268da746ab5fd0688e7', 24, 2, '', 'y', 'received', '2012-08-16 17:35:53');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (57, 'f48590f328fb18c9be474eaee0b357dd', 26, 2, '', 'y', 'received', '2012-08-16 22:03:10');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (58, 'f48590f328fb18c9be474eaee0b357dd', 39, 2, '', 'y', 'received', '2012-08-16 22:03:20');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (59, 'f48590f328fb18c9be474eaee0b357dd', 26, 2, '', 'n', 'received', '2012-08-17 13:23:13');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (60, 'f48590f328fb18c9be474eaee0b357dd', 18, 1, '', 'n', 'received', '2012-08-17 13:36:48');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (61, 'ff57581573c73f12dc0a503d85bf87d4', 26, 2, '', 'n', 'received', '2012-08-19 09:16:33');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (62, 'ff57581573c73f12dc0a503d85bf87d4', 43, 3, 'culinoaa', 'n', 'received', '2012-08-19 12:47:53');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (63, 'ff57581573c73f12dc0a503d85bf87d4', 28, 2, '', 'n', 'received', '2012-08-19 08:06:22');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (64, 'ff57581573c73f12dc0a503d85bf87d4', 39, 1, 'nullino', 'n', 'received', '2012-08-19 09:07:15');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (66, 'ff57581573c73f12dc0a503d85bf87d4', 35, 2, '', 'n', 'received', '2012-08-19 13:26:01');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (65, 'ff57581573c73f12dc0a503d85bf87d4', 23, 2, '', 'n', 'received', '2012-08-19 09:14:38');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (67, 'ed06eaada713bce497988957f5a337ea', 45, 2, 'well done', 'y', 'received', '2012-08-19 13:33:29');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (68, 'ed06eaada713bce497988957f5a337ea', 39, 2, '', 'y', 'received', '2012-08-19 13:33:45');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (69, 'ed06eaada713bce497988957f5a337ea', 43, 2, 'sdsd', 'y', 'received', '2012-08-19 13:52:02');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (70, 'ed06eaada713bce497988957f5a337ea', 39, 2, '', 'y', 'received', '2012-08-19 13:52:11');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (71, '85837848bcc081e91a4b028107fa3043', 47, 2, 'well done', 'y', 'received', '2012-08-19 13:54:16');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (72, '85837848bcc081e91a4b028107fa3043', 39, 2, '', 'y', 'received', '2012-08-19 13:54:28');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (73, '85837848bcc081e91a4b028107fa3043', 26, 2, '', 'y', 'received', '2012-08-19 13:55:10');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (74, 'c0d0b37efffc865c99cfaa66ffb87f16', 49, 2, 'well done', 'y', 'received', '2012-08-19 13:58:44');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (75, 'c0d0b37efffc865c99cfaa66ffb87f16', 39, 2, '', 'y', 'received', '2012-08-19 13:58:55');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (76, 'c0d0b37efffc865c99cfaa66ffb87f16', 43, 1, '', 'y', 'received', '2012-08-19 13:59:29');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (77, 'fbbb96fe7fccf832772f97c49a37a3b3', 47, 2, 'well done', 'y', 'received', '2012-08-19 14:05:49');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (78, '2517d5aafb66797fd9e2c8b8ae323bfd', 49, 2, 'test note', 'y', 'received', '2012-08-19 14:10:59');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (79, '878c5e9c43a09d4e9f9c77e27a5bdc2e', 49, 2, 'well done', 'y', 'received', '2012-08-19 14:13:09');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (80, 'da299d3ae2af63791f19a3cead6ce1a8', 49, 2, 'well done', 'y', 'received', '2012-08-19 14:24:16');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (81, 'da299d3ae2af63791f19a3cead6ce1a8', 39, 2, '', 'y', 'received', '2012-08-19 14:24:29');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (82, 'da299d3ae2af63791f19a3cead6ce1a8', 39, 2, '', 'y', 'received', '2012-08-19 14:25:15');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (83, 'd2fc91e2d4ce2d0609e3b578a406471c', 43, 2, 'nota test 123', 'y', 'received', '2012-08-20 09:29:39');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (84, 'd2fc91e2d4ce2d0609e3b578a406471c', 43, 2, 'nota 1', 'y', 'received', '2012-08-20 11:03:11');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (85, 'd2fc91e2d4ce2d0609e3b578a406471c', 26, 2, 'nota 2', 'y', 'received', '2012-08-20 11:03:28');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (86, 'd2fc91e2d4ce2d0609e3b578a406471c', 39, 2, 'nota 1', 'y', 'received', '2012-08-20 11:03:52');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (87, 'd2fc91e2d4ce2d0609e3b578a406471c', 37, 2, 'nota 3', 'y', 'received', '2012-08-20 11:04:03');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (88, 'd2fc91e2d4ce2d0609e3b578a406471c', 43, 1, '', 'n', 'received', '2012-08-25 10:18:15');


#
# TABLE STRUCTURE FOR: permissions
#

DROP TABLE IF EXISTS permissions;

CREATE TABLE `permissions` (
  `fk_idModules` int(11) NOT NULL,
  `fk_idRoles` int(11) NOT NULL,
  KEY `fk_idRoles` (`fk_idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (0, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 4);


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS roles;

CREATE TABLE `roles` (
  `idRoles` int(11) NOT NULL,
  `label` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO roles (`idRoles`, `label`) VALUES (0, 'admin');
INSERT INTO roles (`idRoles`, `label`) VALUES (1, 'supervisor');
INSERT INTO roles (`idRoles`, `label`) VALUES (2, 'staff manager');
INSERT INTO roles (`idRoles`, `label`) VALUES (3, 'cook');
INSERT INTO roles (`idRoles`, `label`) VALUES (4, 'waiter');


#
# TABLE STRUCTURE FOR: sessions
#

DROP TABLE IF EXISTS sessions;

CREATE TABLE `sessions` (
  `idSessions` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(45) DEFAULT NULL,
  `fk_idTables` int(11) DEFAULT NULL,
  `extras` mediumtext,
  `ticket` mediumtext NOT NULL,
  `bell` enum('y','n') DEFAULT 'n',
  `suspended` enum('y','n') DEFAULT 'n',
  `status` enum('insession','checkedout') NOT NULL DEFAULT 'insession',
  PRIMARY KEY (`idSessions`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (15, '27247c410786f8af754b4eb58787f75c', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1337026660,\"currentround\":4,\"currentitems\":0,\"diners\":{\"adults\":\"2\",\"children\":\"2\"}}', '{\"total\":73.4,\"fixed\":{\"adultsnr\":\"2\",\"childrennr\":\"2\",\"adults\":22.54,\"children\":12.98},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"18\",\"idOrders\":\"10\",\"price\":20.93,\"number\":\"7\"},{\"label\":\"Item numero 3\",\"idMenulists\":\"37\",\"idOrders\":\"11\",\"price\":14.95,\"number\":\"5\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"20\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (21, 'b3b1fffcc876f52650257f72198fc5b8', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\",\"diners\":{\"adults\":\"2\",\"children\":\"2\"}}', '{\"total\":35.52,\"fixed\":{\"adultsnr\":\"2\",\"childrennr\":\"2\",\"adults\":22.54,\"children\":12.98},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (22, '52dd7d495a1bb29d921550867d57fb7c', 2, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1338931207,\"currentround\":3,\"currentitems\":0,\"diners\":{\"adults\":\"1\",\"children\":\"1\"}}', '{\"total\":19.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"28\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (29, '8d0b00f1d0d2e8e99b452f38215f357f', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\",\"diners\":{\"adults\":\"1\",\"children\":\"1\"}}', '{\"total\":17.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (30, '75d991cf066f547e95f07556d808f1c2', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1339023868,\"currentround\":3,\"currentitems\":0,\"diners\":{\"adults\":\"0\",\"children\":\"0\"}}', '{\"total\":2,\"fixed\":{\"adultsnr\":\"0\",\"childrennr\":\"0\",\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"33\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (31, 'c5d6d8aad6d3d828f3e87cf5f98de5a4', 3, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1338931050,\"currentround\":1,\"currentitems\":0,\"diners\":{\"adults\":\"1\",\"children\":\"0\"}}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (32, 'b6cd8129a47100d8ba88efaf6d3f5718', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1339232311,\"currentround\":1,\"currentitems\":0,\"diners\":{\"adults\":\"0\",\"children\":\"0\"}}', '{\"total\":15.95,\"fixed\":{\"adultsnr\":\"0\",\"childrennr\":\"0\",\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"18\",\"idOrders\":\"41\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Item numero 1\",\"idMenulists\":\"35\",\"idOrders\":\"39\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Item numero 3\",\"idMenulists\":\"37\",\"idOrders\":\"40\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"38\",\"price\":1,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (33, '0691fe0749b1ee28a4aace2f63ae126a', NULL, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\",\"diners\":{\"adults\":\"0\",\"children\":\"0\"}}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (34, 'a37e014e95fdc6a8915c1fdcb5290c62', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (35, '3a150d4f9839b51a0da4b18f9933e27a', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"18\",\"idOrders\":\"42\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (36, '252bac7ae8794c9b40c054c8b08f8803', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (37, 'da299d3ae2af63791f19a3cead6ce1a8', 2, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":9.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"81\",\"price\":4,\"number\":\"4\"},{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"49\",\"idOrders\":\"80\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (38, '079ae02de0411a09d585a220772dc206', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"43\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (39, 'a4888526acc0a0ac778cfaa3c4109345', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"47\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (40, '4640b22e0612366d673c21f2ffc47711', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"48\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (41, 'e3007fc2f2b9b3fc942ff1e052b16bf8', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"49\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (42, 'adb9ae1f14ed8986ead92ce55207e589', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":2.99,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"50\",\"price\":2.99,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (43, '71067202fd433b6f7e33caa3ce0ae1b6', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":2.99,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"51\",\"price\":2.99,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (44, 'e38d72ea41a1cd46121a95997988eea3', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":2.99,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"52\",\"price\":2.99,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (45, '01bf60bf3f776021bc7a19e1e9c4bd24', 21, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (46, 'a82d2b68d9cb584fbd22a39416026ffb', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (47, '1e5bc7d375076268da746ab5fd0688e7', 1, '{\"mininterval\":\"600\",\"maxitems\":\"999\",\"maxrounds\":\"999\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":9.97,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"24\",\"idOrders\":\"55\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Item numero 3\",\"idMenulists\":\"26\",\"idOrders\":\"53\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"54\",\"price\":1,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (48, 'f48590f328fb18c9be474eaee0b357dd', 1, '{\"mininterval\":\"600\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":7.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"57\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"58\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (49, 'ff57581573c73f12dc0a503d85bf87d4', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (50, 'ed06eaada713bce497988957f5a337ea', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":15.96,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"68\",\"price\":4,\"number\":\"4\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"69\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Food number 1\",\"idMenulists\":\"45\",\"idOrders\":\"67\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (51, '85837848bcc081e91a4b028107fa3043', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":13.96,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"73\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"72\",\"price\":2,\"number\":\"2\"},{\"label\":\"Food number 3\",\"idMenulists\":\"47\",\"idOrders\":\"71\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (52, 'c0d0b37efffc865c99cfaa66ffb87f16', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":10.97,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"75\",\"price\":2,\"number\":\"2\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"76\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"49\",\"idOrders\":\"74\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (53, 'fbbb96fe7fccf832772f97c49a37a3b3', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"47\",\"idOrders\":\"77\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (54, '2517d5aafb66797fd9e2c8b8ae323bfd', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"49\",\"idOrders\":\"78\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (55, '878c5e9c43a09d4e9f9c77e27a5bdc2e', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"49\",\"idOrders\":\"79\",\"price\":5.98,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (56, 'd2fc91e2d4ce2d0609e3b578a406471c', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":25.92,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"85\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Food number 3\",\"idMenulists\":\"37\",\"idOrders\":\"87\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"86\",\"price\":2,\"number\":\"2\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"83\",\"price\":11.96,\"number\":\"4\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (57, '2dedc62db26155daf280def659e5b1e8', 4, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (58, 'e25c012efd6695aad7dd72f21c178aaa', 2, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (59, '1daebdf7da361269c1c85dae104633dc', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'insession');


#
# TABLE STRUCTURE FOR: tables
#

DROP TABLE IF EXISTS tables;

CREATE TABLE `tables` (
  `idTables` int(11) NOT NULL AUTO_INCREMENT,
  `tableName` varchar(45) NOT NULL,
  PRIMARY KEY (`idTables`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO tables (`idTables`, `tableName`) VALUES (1, '10');
INSERT INTO tables (`idTables`, `tableName`) VALUES (2, '20');
INSERT INTO tables (`idTables`, `tableName`) VALUES (3, '30');
INSERT INTO tables (`idTables`, `tableName`) VALUES (4, '40');
INSERT INTO tables (`idTables`, `tableName`) VALUES (8, '60');
INSERT INTO tables (`idTables`, `tableName`) VALUES (7, '50');
INSERT INTO tables (`idTables`, `tableName`) VALUES (20, '80');
INSERT INTO tables (`idTables`, `tableName`) VALUES (19, '70');
INSERT INTO tables (`idTables`, `tableName`) VALUES (21, '90');


#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `idTickets` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(64) NOT NULL,
  `ticket` mediumtext NOT NULL,
  PRIMARY KEY (`idTickets`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (47, 'd2fc91e2d4ce2d0609e3b578a406471c', '{\"total\":25.92,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"85\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Food number 3\",\"idMenulists\":\"37\",\"idOrders\":\"87\",\"price\":5.98,\"number\":\"2\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"86\",\"price\":2,\"number\":\"2\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"83\",\"price\":11.96,\"number\":\"4\"}]}');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` tinyint(4) NOT NULL,
  PRIMARY KEY (`idUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (0, '', '', '', 'admin', '098f6bcd4621d373cade4e832627b4f6', 0);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (2, 'Mario', 'Rossi', '', 'manager', '098f6bcd4621d373cade4e832627b4f6', 2);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (1, 'Gino', 'Bianchi', '', 'supervisor', '098f6bcd4621d373cade4e832627b4f6', 1);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (3, 'Paolo', 'Verdi', '', 'cook', '098f6bcd4621d373cade4e832627b4f6', 3);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (4, 'John', 'Waiter', '', 'waiter', '098f6bcd4621d373cade4e832627b4f6', 4);


