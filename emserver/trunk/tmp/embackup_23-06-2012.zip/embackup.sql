#
# TABLE STRUCTURE FOR: bqueue
#

DROP TABLE IF EXISTS bqueue;

CREATE TABLE `bqueue` (
  `idBqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idBqueue`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO bqueue (`idBqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (9, '8857f8fa65bddc751b948c3b001f0494', 33, '75d991cf066f547e95f07556d808f1c2', 'received', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `idCategories` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  PRIMARY KEY (`idCategories`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='Main Courses, Appetizers etc';

INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (14, 'Category one', '', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (12, 'Category two', 'boo', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (15, 'Menu Prova Cat', '', 0, NULL);


#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS config;

CREATE TABLE `config` (
  `device` varchar(45) NOT NULL,
  `key` varchar(45) DEFAULT NULL,
  `value` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'mininterval', '600');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxitems', '3');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxrounds', '5');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'servuilang', 'english');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'restmode', 'allyoucaneat');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'displaymode', 'gridview');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'currency', '€');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'price', '{\"adults\":\"11.27\",\"children\":\"6.49\"}');


#
# TABLE STRUCTURE FOR: images
#

DROP TABLE IF EXISTS images;

CREATE TABLE `images` (
  `idImages` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `fileName` varchar(100) NOT NULL,
  PRIMARY KEY (`idImages`),
  UNIQUE KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (42, 'Coke', 'coca.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (41, 'Pesce2', 'img.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (40, 'Pesce1', '54-2-zoom-2-il_ristorante_5.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (39, 'wine', 'wine2.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (37, 'test', '1.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (38, 'test1', 'MichelV4.png');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `idItems` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `description` mediumtext,
  `idImage` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `extras` mediumtext,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idItems`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT=' food and beverages items';

INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (1, 'Item numero 1', 'testitemdescr\r\nvado a capo', 40, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (2, 'Uno', 'Tre', 0, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (3, 'due onw', 'ono', 37, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (4, 'Item numero 2', 'testdescr1', 39, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (5, 'Item numero 3', 'AA', 41, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (6, 'Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro', 'The server at support.google.com can\'t be found, because the DNS lookup failed. DNS is the network service that translates a website\'s name to its Internet address. This error is most often caused by having no connection to the Internet or a misconfigured network. It can also be caused by an unresponsive DNS server or a firewall preventing Google Chrome from accessing the network.', 40, '2.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (7, 'Coca cola', 'Coca cola', 42, '1.00', NULL, 'n');


#
# TABLE STRUCTURE FOR: kqueue
#

DROP TABLE IF EXISTS kqueue;

CREATE TABLE `kqueue` (
  `idKqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idKqueue`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO kqueue (`idKqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (18, '87a96d40eeec8a114dd591dcc138eb5e', 35, '75d991cf066f547e95f07556d808f1c2', 'received', '2012-06-05 23:16:15');
INSERT INTO kqueue (`idKqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (19, '12c806482b28fd7190ad5949daae1f1f', 36, 'c5d6d8aad6d3d828f3e87cf5f98de5a4', 'received', '2012-06-05 23:17:30');
INSERT INTO kqueue (`idKqueue`, `sid`, `fk_idOrders`, `fk_sid`, `status`, `timestamp`) VALUES (20, '48236adbdd1f0a2a7f915f34a4756e54', 30, '52dd7d495a1bb29d921550867d57fb7c', 'received', '2012-06-05 23:20:07');


#
# TABLE STRUCTURE FOR: menulists
#

DROP TABLE IF EXISTS menulists;

CREATE TABLE `menulists` (
  `idMenulists` int(11) NOT NULL AUTO_INCREMENT,
  `fk_idMenus` int(11) DEFAULT NULL,
  `fk_idCategories` int(11) DEFAULT NULL,
  `fk_idItems` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `categoryPosition` tinyint(4) DEFAULT '0',
  `itemPosition` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idMenulists`),
  KEY `fk_idMenus` (`fk_idMenus`),
  KEY `fk_idCategories` (`fk_idCategories`),
  KEY `fk_idItems` (`fk_idItems`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (24, 31, 14, 6, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (36, 31, 14, 1, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (26, 31, 12, 5, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (5, 31, 13, 4, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (6, 31, 13, 4, '2.99', 1, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (7, 31, 13, 3, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (9, 31, 0, 4, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (10, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (11, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (12, 31, 13, 3, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (23, 31, 12, 6, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (14, 31, 13, 3, '2.99', 1, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (35, 31, 12, 1, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (18, 30, 12, 6, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (28, 31, 14, 4, '2.99', 2, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (30, 31, 14, 4, '2.99', 2, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (33, 31, 14, 6, '2.99', 2, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (39, 30, 14, 7, '1.00', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (38, 30, 12, 4, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (37, 30, 14, 5, '2.99', 1, 1);


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `idMenus` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  `price` tinytext,
  `visible` varchar(10) DEFAULT NULL,
  `menuType` enum('f','c') DEFAULT 'c',
  `foodbev` enum('f','b') DEFAULT 'f',
  `position` tinyint(4) DEFAULT NULL,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idMenus`),
  UNIQUE KEY `label_UNIQUE` (`label`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COMMENT='A la carte, Vegetarian, early birds etc...';

INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (27, 'AhAH', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (26, 'testmenu', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (17, 'Food menu', 'Test Food menu', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (32, 'Menu of the day', '', 0, NULL, NULL, 'y', 'f', 'f', 2, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (31, 'Early Bird Menu', 'tre', 0, NULL, NULL, 'y', 'f', 'f', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (28, 'ahahah', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (29, 'Wine List', 'bla', 0, NULL, NULL, 'y', 'c', 'b', 2, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (30, 'Coffee & Drinks', '', 0, NULL, NULL, 'y', 'c', 'b', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (33, 'test', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (34, 'Menu prova', '', 0, NULL, NULL, 'y', 'c', 'f', 3, 'n');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `idModules` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  PRIMARY KEY (`idModules`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO modules (`idModules`, `label`) VALUES (0, 'admin');
INSERT INTO modules (`idModules`, `label`) VALUES (1, 'menuconf');
INSERT INTO modules (`idModules`, `label`) VALUES (2, 'orders');
INSERT INTO modules (`idModules`, `label`) VALUES (3, 'kitchen');
INSERT INTO modules (`idModules`, `label`) VALUES (4, 'bar');


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS orders;

CREATE TABLE `orders` (
  `idOrders` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(45) NOT NULL,
  `fk_idMenulists` int(11) DEFAULT NULL,
  `number` smallint(6) DEFAULT NULL,
  `ksent` enum('y','n') NOT NULL DEFAULT 'n',
  `status` enum('received','inprogress','done') NOT NULL DEFAULT 'received',
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`idOrders`),
  KEY `fk_idMenulists` (`fk_idMenulists`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (33, '75d991cf066f547e95f07556d808f1c2', 39, 2, 'y', 'received', '2012-06-05 20:50:23');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (34, '75d991cf066f547e95f07556d808f1c2', 35, 2, 'y', 'received', '2012-06-05 20:51:30');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (35, '75d991cf066f547e95f07556d808f1c2', 26, 1, 'y', 'received', '2012-06-05 21:16:07');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (12, '27247c410786f8af754b4eb58787f75c', 35, 4, 'y', 'received', '2012-04-23 17:09:14');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (13, '27247c410786f8af754b4eb58787f75c', 36, 2, 'y', 'received', '2012-04-23 20:43:27');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (39, 'b6cd8129a47100d8ba88efaf6d3f5718', 35, 1, 'y', 'received', '2012-06-09 08:58:25');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (38, 'b6cd8129a47100d8ba88efaf6d3f5718', 39, 1, 'y', 'received', '2012-06-09 08:57:33');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (37, '75d991cf066f547e95f07556d808f1c2', 23, 2, 'y', 'received', '2012-06-06 23:04:20');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (36, 'c5d6d8aad6d3d828f3e87cf5f98de5a4', 23, 1, 'y', 'received', '2012-06-05 21:17:25');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (28, '52dd7d495a1bb29d921550867d57fb7c', 39, 2, 'y', 'received', '2012-05-17 07:01:01');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (29, '52dd7d495a1bb29d921550867d57fb7c', 35, 2, 'y', 'received', '2012-05-17 07:04:50');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `ksent`, `status`, `timestamp`) VALUES (30, '52dd7d495a1bb29d921550867d57fb7c', 35, 3, 'y', 'received', '2012-06-05 21:19:35');


#
# TABLE STRUCTURE FOR: permissions
#

DROP TABLE IF EXISTS permissions;

CREATE TABLE `permissions` (
  `fk_idModules` int(11) NOT NULL,
  `fk_idRoles` int(11) NOT NULL,
  KEY `fk_idRoles` (`fk_idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (0, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 4);


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS roles;

CREATE TABLE `roles` (
  `idRoles` int(11) NOT NULL,
  `label` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO roles (`idRoles`, `label`) VALUES (0, 'admin');
INSERT INTO roles (`idRoles`, `label`) VALUES (1, 'supervisor');
INSERT INTO roles (`idRoles`, `label`) VALUES (2, 'staff manager');
INSERT INTO roles (`idRoles`, `label`) VALUES (3, 'cook');
INSERT INTO roles (`idRoles`, `label`) VALUES (4, 'waiter');


#
# TABLE STRUCTURE FOR: sessions
#

DROP TABLE IF EXISTS sessions;

CREATE TABLE `sessions` (
  `idSessions` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(45) DEFAULT NULL,
  `fk_idTables` int(11) DEFAULT NULL,
  `extras` mediumtext,
  `ticket` mediumtext NOT NULL,
  `bell` enum('y','n') DEFAULT 'n',
  `suspended` enum('y','n') DEFAULT 'n',
  `status` enum('insession','checkedout') NOT NULL DEFAULT 'insession',
  PRIMARY KEY (`idSessions`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (15, '27247c410786f8af754b4eb58787f75c', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1337026660,\"currentround\":4,\"currentitems\":0,\"diners\":{\"adults\":\"2\",\"children\":\"2\"}}', '{\"total\":73.4,\"fixed\":{\"adultsnr\":\"2\",\"childrennr\":\"2\",\"adults\":22.54,\"children\":12.98},\"carte\":[{\"label\":\"Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro\",\"idMenulists\":\"18\",\"idOrders\":\"10\",\"price\":20.93,\"number\":\"7\"},{\"label\":\"Item numero 3\",\"idMenulists\":\"37\",\"idOrders\":\"11\",\"price\":14.95,\"number\":\"5\"},{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"20\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (21, 'b3b1fffcc876f52650257f72198fc5b8', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\",\"diners\":{\"adults\":\"2\",\"children\":\"2\"}}', '{\"total\":35.52,\"fixed\":{\"adultsnr\":\"2\",\"childrennr\":\"2\",\"adults\":22.54,\"children\":12.98},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (22, '52dd7d495a1bb29d921550867d57fb7c', 2, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1338931207,\"currentround\":3,\"currentitems\":0,\"diners\":{\"adults\":\"1\",\"children\":\"1\"}}', '{\"total\":19.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"28\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (29, '8d0b00f1d0d2e8e99b452f38215f357f', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\",\"diners\":{\"adults\":\"1\",\"children\":\"1\"}}', '{\"total\":17.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (30, '75d991cf066f547e95f07556d808f1c2', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1339023868,\"currentround\":3,\"currentitems\":0,\"diners\":{\"adults\":\"0\",\"children\":\"0\"}}', '{\"total\":2,\"fixed\":{\"adultsnr\":\"0\",\"childrennr\":\"0\",\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"33\",\"price\":2,\"number\":\"2\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (31, 'c5d6d8aad6d3d828f3e87cf5f98de5a4', 3, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1338931050,\"currentround\":1,\"currentitems\":0,\"diners\":{\"adults\":\"1\",\"children\":\"0\"}}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (32, 'b6cd8129a47100d8ba88efaf6d3f5718', 1, '{\"mininterval\":\"600\",\"maxitems\":\"3\",\"maxrounds\":\"5\",\"currentroundts\":1339232311,\"currentround\":1,\"currentitems\":0,\"diners\":{\"adults\":\"1\",\"children\":\"1\"}}', '{\"total\":17.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[]}', 'y', 'n', 'insession');


#
# TABLE STRUCTURE FOR: tables
#

DROP TABLE IF EXISTS tables;

CREATE TABLE `tables` (
  `idTables` int(11) NOT NULL AUTO_INCREMENT,
  `tableName` varchar(45) NOT NULL,
  PRIMARY KEY (`idTables`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO tables (`idTables`, `tableName`) VALUES (1, '10');
INSERT INTO tables (`idTables`, `tableName`) VALUES (2, '20');
INSERT INTO tables (`idTables`, `tableName`) VALUES (3, '30');
INSERT INTO tables (`idTables`, `tableName`) VALUES (4, '40');
INSERT INTO tables (`idTables`, `tableName`) VALUES (8, '60');
INSERT INTO tables (`idTables`, `tableName`) VALUES (7, '50');


#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `idTickets` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(64) NOT NULL,
  `ticket` mediumtext NOT NULL,
  PRIMARY KEY (`idTickets`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (23, '52dd7d495a1bb29d921550867d57fb7c', '{\"total\":19.76,\"fixed\":{\"adultsnr\":\"1\",\"childrennr\":\"1\",\"adults\":11.27,\"children\":6.49},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"28\",\"price\":2,\"number\":\"2\"}]}');
INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (24, '75d991cf066f547e95f07556d808f1c2', '{\"total\":2,\"fixed\":{\"adultsnr\":\"0\",\"childrennr\":\"0\",\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Coca cola\",\"idMenulists\":\"39\",\"idOrders\":\"33\",\"price\":2,\"number\":\"2\"}]}');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` tinyint(4) NOT NULL,
  PRIMARY KEY (`idUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (0, '', '', '', 'admin', '098f6bcd4621d373cade4e832627b4f6', 0);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (2, 'Mario', 'Rossi', '', 'manager', '098f6bcd4621d373cade4e832627b4f6', 2);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (1, 'Gino', 'Bianchi', '', 'supervisor', '098f6bcd4621d373cade4e832627b4f6', 1);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (3, 'Paolo', 'Verdi', '', 'cook', '098f6bcd4621d373cade4e832627b4f6', 3);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (4, '', '', '', 'waiter', '098f6bcd4621d373cade4e832627b4f6', 4);


